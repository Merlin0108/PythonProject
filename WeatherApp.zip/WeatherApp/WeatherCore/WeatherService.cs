﻿using System.Net.Http;
using System.Text.Json;


namespace WeatherCore
{
    public class WeatherService
    {
        private const string APIKey = "1ba05f4fb415e8b2a31bc1058b1455ae";
        private const string Url = "https://api.openweathermap.org/data/2.5/weather?q={0}&lang=ru&appid={1}&units=metric";
        public async Task<WeatherData> GetWeatherAsync(string cityName)
        {
            using HttpClient httpClient = new();
            {
                string request = string.Format(Url, cityName, APIKey);
                HttpResponseMessage httpResponse = await httpClient.GetAsync(request);
                httpResponse.EnsureSuccessStatusCode();

                string jsonText = await httpResponse.Content.ReadAsStringAsync();

                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };

                RootWeatherObject weatherObject = JsonSerializer.Deserialize<RootWeatherObject>(jsonText, options);

                WeatherData weatherData = new ()
                {
                    City = weatherObject.Name,
                    Temperature = weatherObject.Main.Temp,
                    FeelsLike = weatherObject.Main.Feels_like,
                    Description = weatherObject.Weather.FirstOrDefault().Description,
                    Humidity = weatherObject.Main.Humidity,
                    WindSpeed = weatherObject.Wind.Speed,                    
                    Date = DateTime.Now
                };

                return weatherData;
            }
        }
    }


    public class RootWeatherObject
    {
        public string Name { get; set; }
        public MainInfo Main { get; set; }
        public List<WeatherInfo> Weather {get; set;}
        public WindInfo Wind { get; set; }

    }

    public class MainInfo
    {
        public double Temp { get; set; }    
        public double Feels_like { get; set; }
        public int Humidity { get; set; }

    }

    public class WindInfo
    {
        public double Speed { get; set; }
    }

    public class WeatherInfo
    {
        public string Description { get; set; }
    }

}


