﻿using System.Text.Json;
using System.IO;
namespace WeatherCore
{
    public class WeatherCacheService
    {
        private const string CacheFilePath = "weather_cache.json";

        public void Save(WeatherData data)
        {
            var json = JsonSerializer.Serialize(data);
            File.WriteAllText(CacheFilePath, json);
        }

        public WeatherData Load()
        {
            if (!File.Exists(CacheFilePath))
                return null;

            var json = File.ReadAllText(CacheFilePath);
            return JsonSerializer.Deserialize<WeatherData>(json);
        }
    }
}
