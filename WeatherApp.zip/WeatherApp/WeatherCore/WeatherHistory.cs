﻿using System.Xml.Linq;
using System.IO;
using System.Globalization;
namespace WeatherCore
{
    public class WeatherHistory
    {
        private const string HistoryFilePath = "weather_history.xml";
        private List<WeatherData> history = new ();

        public void Add(WeatherData data)
        {
            history.Add(data);
            SaveHistory();
        }

        public List<WeatherData> GetAll()
        {
            return history.ToList();
        }

        public List<WeatherData> LoadHistory()
        {
            if (!File.Exists(HistoryFilePath))
                return new List<WeatherData>();

            var doc = XDocument.Load(HistoryFilePath);
            history = doc.Root.Elements("Weather").Select(x => new WeatherData
            {
                City = x.Element("City")?.Value,
                Temperature = double.TryParse(x.Element("Temperature")?.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var temp) ? temp : 0,
                FeelsLike = double.TryParse(x.Element("FeelsLike")?.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var feel)? feel : 0,
                Description = (x.Element("Description")?.Value),
                Humidity = int.TryParse(x.Element("Humidity")?.Value, out var hum) ? hum : 0,
                WindSpeed = double.TryParse(x.Element("WindSpeed")?.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var wind) ? wind : 0,
                Date = DateTime.TryParse(x.Element("Date")?.Value, out var date) ? date : DateTime.Now
            }).ToList();
            return history;
        }

        private void SaveHistory()
        {
            var doc = new XDocument(new XElement("WeatherHistory",
                history.Select(w => new XElement("Weather",
                new XElement("City", w.City),
                new XElement("Temperature", w.Temperature),
                new XElement("FeelsLike", w.FeelsLike),
                new XElement("Description", w.Description),
                new XElement("Humidity", w.Humidity),
                new XElement("WindSpeed", w.WindSpeed),
                new XElement("Date", w.Date)))));
            doc.Save(HistoryFilePath);
        }

        public void ClearHistory()
        {
            if (File.Exists(HistoryFilePath))
            {
                var emptyDoc = new XDocument(new XElement("WeatherHistory"));
                emptyDoc.Save(HistoryFilePath);
            }
            history = new List<WeatherData>();
        }
    }
}
