﻿namespace WeatherCore
{
    [Serializable]
    public class WeatherData
    {
        public string City { get; set; }
        public double Temperature { get; set; }
        public double FeelsLike { get; set; }
        public string Description { get; set; }
        public int Humidity { get; set; }
        public double WindSpeed { get; set; }
        public DateTime Date { get; set; }
        public override string ToString()
        {
            return $"Город: {City}\nТемпература: {Temperature}C\nОщущяется как: {FeelsLike}C\nОписание: {Description}\nВлажность: {Humidity}%\nСкорость ветра: {WindSpeed} м/с\nДата: {Date}";
        }

    }
}
