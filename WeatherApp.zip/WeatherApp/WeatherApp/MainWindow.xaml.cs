﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Text.RegularExpressions;
using WeatherCore;
namespace WeatherApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly WeatherService weatherService = new WeatherService();
        private readonly WeatherCacheService cacheService = new WeatherCacheService();
        private readonly WeatherHistory weatherHistory = new WeatherHistory();

        private readonly List<WeatherData> history = new List<WeatherData>();
        public MainWindow()
        {
            InitializeComponent();

            history = weatherHistory.LoadHistory();
            UpdateHistoryListBox();

            var lastWeather = cacheService.Load();
            if (lastWeather != null)
            {
                WeatherTextBlock.Text = "Последний запрос:\n" + FormatWeather(lastWeather);
            }
        }

        private async void OnGetWeatherClicked(object sender, RoutedEventArgs e)
        {
            try
            {
                string cityName = CityTextBox.Text.Trim();

                if (string.IsNullOrEmpty(cityName) || !Regex.IsMatch(cityName, @"^[а-яА-ЯёЁ\-]+$"))
                {
                    MessageBox.Show("Введите название города.");
                    return;
                }

                WeatherData weatherData = await weatherService.GetWeatherAsync(cityName);
                cacheService.Save(weatherData);
                weatherHistory.Add(weatherData);
                WeatherTextBlock.Text = FormatWeather(weatherData);
                UpdateHistoryListBox();
                
            }
            catch (Exception)
            {
                MessageBox.Show("Город не найден");
            }
        }

        private void UpdateHistoryListBox()
        {
            var filtered = weatherHistory.GetAll().OrderByDescending(w => w.Date).ToList();
            HistoryDataGrid.ItemsSource = null;
            HistoryDataGrid.ItemsSource = filtered;
        }

        private string FormatWeather(WeatherData data)
        {
            return $"Город: {data.City}\nТемпература: {data.Temperature}С\nОщущаяется как: {data.FeelsLike}C\nОписание: {data.Description}\nВлажность: {data.Humidity}%\nВетер: {data.WindSpeed} м/с\nВремя: {data.Date}";
        }

        private void Clear(object sender, RoutedEventArgs e)
        {

        }

        private void ClearHistoryButton(object sender, RoutedEventArgs e)
        {
            weatherHistory.ClearHistory();
            MessageBox.Show("История очищена");
            UpdateHistoryListBox();
        }
    }
}
